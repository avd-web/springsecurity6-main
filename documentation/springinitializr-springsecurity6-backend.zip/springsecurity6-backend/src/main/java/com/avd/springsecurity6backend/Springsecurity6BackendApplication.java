package com.avd.springsecurity6backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springsecurity6BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springsecurity6BackendApplication.class, args);
	}

}
