package com.avd.springsecurity6backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springsecurity6BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
